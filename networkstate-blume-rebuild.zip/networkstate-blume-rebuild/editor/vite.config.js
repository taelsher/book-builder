import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { docsApiPlugin } from "./src/server/docsApiPlugin.js";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const editorRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)));

export default defineConfig({
  plugins: [react(), tailwindcss(), docsApiPlugin(projectRoot)],
  resolve: {
    alias: {
      "@": path.join(editorRoot, "src"),
    },
  },
  // Serve the main site's public/ dir (not editor/public) so existing and
  // newly-uploaded images under /images/... resolve inside the editor too.
  publicDir: path.join(projectRoot, "public"),
  server: { port: 5180 },
});
